// ─── BODY REGIONS (FRONT) ─────────────────────────────────────────────────────
export const REGIONS_FRONT = [
    { id: "head", label: "Head", d: "M200,18 C178,18 160,36 160,58 C160,78 172,95 190,100 L190,112 L210,112 L210,100 C228,95 240,78 240,58 C240,36 222,18 200,18 Z" },
    { id: "neck", label: "Neck", d: "M190,112 L190,130 L210,130 L210,112 Z" },
    { id: "lShoulder", label: "Left Shoulder", d: "M155,130 C140,130 125,138 118,152 L128,165 C135,152 144,145 155,143 L155,130 Z" },
    { id: "rShoulder", label: "Right Shoulder", d: "M245,130 C260,130 275,138 282,152 L272,165 C265,152 256,145 245,143 L245,130 Z" },
    { id: "chest", label: "Chest", d: "M155,130 L155,195 L200,205 L245,195 L245,130 L210,128 L190,128 Z" },
    { id: "abdomen", label: "Abdomen", d: "M155,195 L155,255 L162,268 L200,275 L238,268 L245,255 L245,195 L200,205 Z" },
    { id: "lUpperArm", label: "Left Upper Arm", d: "M118,152 L105,155 L95,210 L115,215 L128,165 Z" },
    { id: "rUpperArm", label: "Right Upper Arm", d: "M282,152 L295,155 L305,210 L285,215 L272,165 Z" },
    { id: "lForearm", label: "Left Forearm", d: "M95,210 L88,270 L108,273 L115,215 Z" },
    { id: "rForearm", label: "Right Forearm", d: "M305,210 L312,270 L292,273 L285,215 Z" },
    { id: "lHand", label: "Left Hand", d: "M88,270 L82,305 C82,312 88,316 95,314 L110,310 L108,273 Z" },
    { id: "rHand", label: "Right Hand", d: "M312,270 L318,305 C318,312 312,316 305,314 L290,310 L292,273 Z" },
    { id: "lHip", label: "Left Hip", d: "M162,268 L155,255 L155,270 L148,320 L178,325 L185,275 Z" },
    { id: "rHip", label: "Right Hip", d: "M238,268 L245,255 L245,270 L252,320 L222,325 L215,275 Z" },
    { id: "lThigh", label: "Left Thigh", d: "M148,320 L140,390 L168,393 L178,325 Z" },
    { id: "rThigh", label: "Right Thigh", d: "M252,320 L260,390 L232,393 L222,325 Z" },
    { id: "lKnee", label: "Left Knee", d: "M140,390 L136,420 L166,423 L168,393 Z" },
    { id: "rKnee", label: "Right Knee", d: "M260,390 L264,420 L234,423 L232,393 Z" },
    { id: "lShin", label: "Left Shin", d: "M136,420 L132,490 L162,492 L166,423 Z" },
    { id: "rShin", label: "Right Shin", d: "M264,420 L268,490 L238,492 L234,423 Z" },
    { id: "lFoot", label: "Left Foot", d: "M132,490 L126,515 C120,522 125,528 134,528 L162,526 L162,492 Z" },
    { id: "rFoot", label: "Right Foot", d: "M268,490 L274,515 C280,522 275,528 266,528 L238,526 L238,492 Z" },
];

// ─── BODY REGIONS (BACK) ──────────────────────────────────────────────────────
export const REGIONS_BACK = [
    { id: "head_b", label: "Head (back)", d: "M200,18 C178,18 160,36 160,58 C160,78 172,95 190,100 L190,112 L210,112 L210,100 C228,95 240,78 240,58 C240,36 222,18 200,18 Z" },
    { id: "neck_b", label: "Neck (back)", d: "M190,112 L190,130 L210,130 L210,112 Z" },
    { id: "lShoulder_b", label: "Left Shoulder (back)", d: "M155,130 C140,130 125,138 118,152 L128,165 C135,152 144,145 155,143 L155,130 Z" },
    { id: "rShoulder_b", label: "Right Shoulder (back)", d: "M245,130 C260,130 275,138 282,152 L272,165 C265,152 256,145 245,143 L245,130 Z" },
    { id: "upperBack", label: "Upper Back", d: "M155,130 L155,195 L200,205 L245,195 L245,130 L210,128 L190,128 Z" },
    { id: "lowerBack", label: "Lower Back", d: "M155,195 L155,255 L162,268 L200,275 L238,268 L245,255 L245,195 L200,205 Z" },
    { id: "lUpperArm_b", label: "Left Upper Arm (back)", d: "M118,152 L105,155 L95,210 L115,215 L128,165 Z" },
    { id: "rUpperArm_b", label: "Right Upper Arm (back)", d: "M282,152 L295,155 L305,210 L285,215 L272,165 Z" },
    { id: "lForearm_b", label: "Left Forearm (back)", d: "M95,210 L88,270 L108,273 L115,215 Z" },
    { id: "rForearm_b", label: "Right Forearm (back)", d: "M305,210 L312,270 L292,273 L285,215 Z" },
    { id: "lHand_b", label: "Left Hand (back)", d: "M88,270 L82,305 C82,312 88,316 95,314 L110,310 L108,273 Z" },
    { id: "rHand_b", label: "Right Hand (back)", d: "M312,270 L318,305 C318,312 312,316 305,314 L290,310 L292,273 Z" },
    { id: "lGlute", label: "Left Glute", d: "M162,268 L155,255 L155,270 L148,320 L178,325 L185,275 Z" },
    { id: "rGlute", label: "Right Glute", d: "M238,268 L245,255 L245,270 L252,320 L222,325 L215,275 Z" },
    { id: "lHamstring", label: "Left Hamstring", d: "M148,320 L140,390 L168,393 L178,325 Z" },
    { id: "rHamstring", label: "Right Hamstring", d: "M252,320 L260,390 L232,393 L222,325 Z" },
    { id: "lKnee_b", label: "Left Knee (back)", d: "M140,390 L136,420 L166,423 L168,393 Z" },
    { id: "rKnee_b", label: "Right Knee (back)", d: "M260,390 L264,420 L234,423 L232,393 Z" },
    { id: "lCalf", label: "Left Calf", d: "M136,420 L132,490 L162,492 L166,423 Z" },
    { id: "rCalf", label: "Right Calf", d: "M264,420 L268,490 L238,492 L234,423 Z" },
    { id: "lFoot_b", label: "Left Foot (back)", d: "M132,490 L126,515 C120,522 125,528 134,528 L162,526 L162,492 Z" },
    { id: "rFoot_b", label: "Right Foot (back)", d: "M268,490 L274,515 C280,522 275,528 266,528 L238,526 L238,492 Z" },
];

// ─── ANATOMICAL DETAIL OVERLAYS ───────────────────────────────────────────────
// Non-interactive decorative paths rendered on top of the body silhouette.
// Front: face features, chest line, navel, knees
// Back:  spine, shoulder blades, glute crease, calf definition

export const FRONT_DETAILS = `
  <!-- Eyes -->
  <ellipse cx="191" cy="55" rx="4" ry="3" fill="#7c3aed" opacity="0.35"/>
  <ellipse cx="209" cy="55" rx="4" ry="3" fill="#7c3aed" opacity="0.35"/>
  <!-- Nose bridge -->
  <path d="M200,60 Q197,68 199,72" fill="none" stroke="#7c3aed" stroke-width="1.2" opacity="0.3" stroke-linecap="round"/>
  <!-- Mouth -->
  <path d="M194,78 Q200,83 206,78" fill="none" stroke="#7c3aed" stroke-width="1.2" opacity="0.3" stroke-linecap="round"/>
  <!-- Ear left -->
  <path d="M160,57 Q155,62 160,67" fill="none" stroke="#7c3aed" stroke-width="1.5" opacity="0.25" stroke-linecap="round"/>
  <!-- Ear right -->
  <path d="M240,57 Q245,62 240,67" fill="none" stroke="#7c3aed" stroke-width="1.5" opacity="0.25" stroke-linecap="round"/>
  <!-- Chest centre line -->
  <path d="M200,135 L200,195" fill="none" stroke="#7c3aed" stroke-width="1" opacity="0.18" stroke-linecap="round"/>
  <!-- Pec curves -->
  <path d="M165,150 Q183,162 200,158 Q217,162 235,150" fill="none" stroke="#7c3aed" stroke-width="1.2" opacity="0.2" stroke-linecap="round"/>
  <!-- Navel -->
  <circle cx="200" cy="233" r="3" fill="none" stroke="#7c3aed" stroke-width="1.2" opacity="0.3"/>
  <!-- Abs lines -->
  <path d="M189,210 Q200,214 211,210" fill="none" stroke="#7c3aed" stroke-width="1" opacity="0.18" stroke-linecap="round"/>
  <path d="M187,225 Q200,229 213,225" fill="none" stroke="#7c3aed" stroke-width="1" opacity="0.18" stroke-linecap="round"/>
  <!-- Knee caps -->
  <ellipse cx="154" cy="408" rx="10" ry="7" fill="none" stroke="#7c3aed" stroke-width="1.2" opacity="0.25"/>
  <ellipse cx="248" cy="408" rx="10" ry="7" fill="none" stroke="#7c3aed" stroke-width="1.2" opacity="0.25"/>
`;

export const BACK_DETAILS = `
  <!-- Skull back curve -->
  <path d="M178,30 Q200,22 222,30" fill="none" stroke="#7c3aed" stroke-width="1.2" opacity="0.25" stroke-linecap="round"/>
  <!-- Ears -->
  <path d="M160,57 Q155,62 160,67" fill="none" stroke="#7c3aed" stroke-width="1.5" opacity="0.25" stroke-linecap="round"/>
  <path d="M240,57 Q245,62 240,67" fill="none" stroke="#7c3aed" stroke-width="1.5" opacity="0.25" stroke-linecap="round"/>
  <!-- Spine -->
  <path d="M200,128 L200,268" fill="none" stroke="#7c3aed" stroke-width="2" opacity="0.28" stroke-linecap="round" stroke-dasharray="4 3"/>
  <!-- Vertebrae dots -->
  <circle cx="200" cy="140" r="2.5" fill="#7c3aed" opacity="0.22"/>
  <circle cx="200" cy="153" r="2.5" fill="#7c3aed" opacity="0.22"/>
  <circle cx="200" cy="166" r="2.5" fill="#7c3aed" opacity="0.22"/>
  <circle cx="200" cy="179" r="2.5" fill="#7c3aed" opacity="0.22"/>
  <circle cx="200" cy="192" r="2.5" fill="#7c3aed" opacity="0.22"/>
  <circle cx="200" cy="210" r="2.5" fill="#7c3aed" opacity="0.22"/>
  <circle cx="200" cy="228" r="2.5" fill="#7c3aed" opacity="0.22"/>
  <circle cx="200" cy="246" r="2.5" fill="#7c3aed" opacity="0.22"/>
  <!-- Left shoulder blade -->
  <path d="M163,140 Q155,158 160,178 Q170,185 178,175 Q182,158 175,140 Z" fill="none" stroke="#7c3aed" stroke-width="1.3" opacity="0.28" stroke-linejoin="round"/>
  <!-- Right shoulder blade -->
  <path d="M237,140 Q245,158 240,178 Q230,185 222,175 Q218,158 225,140 Z" fill="none" stroke="#7c3aed" stroke-width="1.3" opacity="0.28" stroke-linejoin="round"/>
  <!-- Glute crease -->
  <path d="M200,268 L200,310" fill="none" stroke="#7c3aed" stroke-width="1.5" opacity="0.22" stroke-linecap="round"/>
  <!-- Calf definition -->
  <path d="M142,435 Q138,460 140,480" fill="none" stroke="#7c3aed" stroke-width="1.2" opacity="0.22" stroke-linecap="round"/>
  <path d="M258,435 Q262,460 260,480" fill="none" stroke="#7c3aed" stroke-width="1.2" opacity="0.22" stroke-linecap="round"/>
`;

// ─── COMBINED for convenience ──────────────────────────────────────────────────
// PatientPage imports REGIONS_FRONT and REGIONS_BACK separately.
// Legacy REGIONS alias kept so nothing else breaks.
export const REGIONS = REGIONS_FRONT;

// ─── ROLES ────────────────────────────────────────────────────────────────────
export const ROLES = [
    { id: "patient", label: "Patient", icon: "", desc: "Report symptoms & pain areas" },
    { id: "doctor", label: "Doctor", icon: "", desc: "Review patient submissions" },
];

// ─── SYMPTOMS ─────────────────────────────────────────────────────────────────
export const SYMPTOMS = [
    { id: "bleeding", label: "Bleeding", file: "Bleeding.png" },
    { id: "bloating", label: "Bloating", file: "Bloating.jpg" },
    { id: "bruise", label: "Bruise", file: "Bruise.jpg" },
    { id: "burning_pain", label: "Burning Pain", file: "Burning_Pain.png" },
    { id: "cough", label: "Cough", file: "Cough.png" },
    { id: "cramps", label: "Cramps", file: "Cramps.jpg" },
    { id: "cut", label: "Cut", file: "Cut.png" },
    { id: "dizziness", label: "Dizziness", file: "Dizziness.jpg" },
    { id: "dull_pain", label: "Dull Pain", file: "Dull_Pain.jpg" },
    { id: "headache", label: "Headache", file: "headache.jpg" },
    { id: "heart_racing", label: "Heart Racing", file: "Heart_Racing.png" },
    { id: "hit_head", label: "Hit Head", file: "Hit_Head.png" },
    { id: "injury", label: "Injury", file: "Injury.jpg" },
    { id: "itching", label: "Itching", file: "Itching.jpg" },
    { id: "muscle_pain", label: "Muscle Pain", file: "Muscle_Pain.png" },
    { id: "nausea", label: "Nausea", file: "Nausea.png" },
    { id: "numbness", label: "Numbness", file: "Numbness.jpg" },
    { id: "other", label: "Other", file: "Other.jpg" },
    { id: "pain_going_down_leg", label: "Pain Going Down Leg", file: "Pain_Going_Down_Leg.jpg" },
    { id: "pain_sitting_down", label: "Pain Sitting Down", file: "Pain_Sitting_Down.jpg" },
    { id: "pressure_pain", label: "Pressure Pain", file: "Pressure_Pain.png" },
    { id: "rash", label: "Rash", file: "Rash.png" },
    { id: "sharp_pain", label: "Sharp Pain", file: "Sharp_Pain.jpg" },
    { id: "spasm", label: "Spasm", file: "Spasm.jpg" },
    { id: "stiffness", label: "Stiffness", file: "Stiffness.png" },
    { id: "swelling", label: "Swelling", file: "Swelling.jpg" },
    { id: "throbbing_pain", label: "Throbbing Pain", file: "Throbbing_Pain.jpg" },
    { id: "tightness", label: "Tightness", file: "Tightness.png" },
    { id: "tingling_pain", label: "Tingling Pain", file: "Tingling_Pain.png" },
    { id: "trouble_bending", label: "Trouble Bending Over", file: "Trouble_Bending_Over.png" },
    { id: "trouble_lifting_arm", label: "Trouble Lifting Arm", file: "Trouble_Lifting_Arm.png" },
    { id: "trouble_moving", label: "Trouble Moving", file: "Trouble_Moving.png" },
    { id: "trouble_using_hand", label: "Trouble Using Hand", file: "Trouble_Using_Hand.png" },
    { id: "vomiting", label: "Vomiting", file: "Vomiting.jpg" },
    { id: "weakness", label: "Weakness", file: "Weakness.png" },
];

// ─── REGION → SYMPTOM RELEVANCE MAP ──────────────────────────────────────────
export const REGION_SYMPTOM_MAP: Record<string, string[]> = {
    head: ["headache", "dizziness", "nausea", "vomiting", "hit_head", "throbbing_pain", "pressure_pain", "numbness", "tingling_pain", "other"],
    head_b: ["headache", "dizziness", "nausea", "hit_head", "throbbing_pain", "pressure_pain", "other"],
    neck: ["stiffness", "sharp_pain", "dull_pain", "throbbing_pain", "tightness", "numbness", "tingling_pain", "muscle_pain", "other"],
    neck_b: ["stiffness", "sharp_pain", "dull_pain", "tightness", "numbness", "muscle_pain", "other"],
    lShoulder: ["sharp_pain", "dull_pain", "stiffness", "swelling", "trouble_lifting_arm", "muscle_pain", "tightness", "throbbing_pain", "injury", "bruise", "other"],
    rShoulder: ["sharp_pain", "dull_pain", "stiffness", "swelling", "trouble_lifting_arm", "muscle_pain", "tightness", "throbbing_pain", "injury", "bruise", "other"],
    lShoulder_b: ["sharp_pain", "dull_pain", "stiffness", "swelling", "trouble_lifting_arm", "muscle_pain", "tightness", "injury", "other"],
    rShoulder_b: ["sharp_pain", "dull_pain", "stiffness", "swelling", "trouble_lifting_arm", "muscle_pain", "tightness", "injury", "other"],
    chest: ["sharp_pain", "pressure_pain", "tightness", "heart_racing", "cough", "burning_pain", "dull_pain", "throbbing_pain", "injury", "other"],
    upperBack: ["sharp_pain", "dull_pain", "stiffness", "muscle_pain", "tightness", "throbbing_pain", "spasm", "trouble_moving", "injury", "other"],
    lowerBack: ["sharp_pain", "dull_pain", "stiffness", "muscle_pain", "tightness", "throbbing_pain", "spasm", "pain_going_down_leg", "trouble_bending", "pain_sitting_down", "injury", "other"],
    abdomen: ["sharp_pain", "dull_pain", "bloating", "cramps", "nausea", "vomiting", "burning_pain", "pressure_pain", "other"],
    lUpperArm: ["sharp_pain", "dull_pain", "muscle_pain", "weakness", "swelling", "bruise", "injury", "throbbing_pain", "tightness", "other"],
    rUpperArm: ["sharp_pain", "dull_pain", "muscle_pain", "weakness", "swelling", "bruise", "injury", "throbbing_pain", "tightness", "other"],
    lUpperArm_b: ["sharp_pain", "dull_pain", "muscle_pain", "weakness", "swelling", "bruise", "injury", "other"],
    rUpperArm_b: ["sharp_pain", "dull_pain", "muscle_pain", "weakness", "swelling", "bruise", "injury", "other"],
    lForearm: ["sharp_pain", "dull_pain", "numbness", "tingling_pain", "weakness", "swelling", "bruise", "cut", "burning_pain", "other"],
    rForearm: ["sharp_pain", "dull_pain", "numbness", "tingling_pain", "weakness", "swelling", "bruise", "cut", "burning_pain", "other"],
    lForearm_b: ["sharp_pain", "dull_pain", "numbness", "tingling_pain", "weakness", "swelling", "bruise", "cut", "other"],
    rForearm_b: ["sharp_pain", "dull_pain", "numbness", "tingling_pain", "weakness", "swelling", "bruise", "cut", "other"],
    lHand: ["sharp_pain", "dull_pain", "numbness", "tingling_pain", "weakness", "swelling", "trouble_using_hand", "cut", "rash", "itching", "bruise", "other"],
    rHand: ["sharp_pain", "dull_pain", "numbness", "tingling_pain", "weakness", "swelling", "trouble_using_hand", "cut", "rash", "itching", "bruise", "other"],
    lHand_b: ["sharp_pain", "dull_pain", "numbness", "tingling_pain", "swelling", "trouble_using_hand", "cut", "rash", "other"],
    rHand_b: ["sharp_pain", "dull_pain", "numbness", "tingling_pain", "swelling", "trouble_using_hand", "cut", "rash", "other"],
    lHip: ["sharp_pain", "dull_pain", "stiffness", "swelling", "trouble_moving", "pain_sitting_down", "throbbing_pain", "injury", "other"],
    rHip: ["sharp_pain", "dull_pain", "stiffness", "swelling", "trouble_moving", "pain_sitting_down", "throbbing_pain", "injury", "other"],
    lGlute: ["sharp_pain", "dull_pain", "muscle_pain", "pain_sitting_down", "pain_going_down_leg", "numbness", "spasm", "other"],
    rGlute: ["sharp_pain", "dull_pain", "muscle_pain", "pain_sitting_down", "pain_going_down_leg", "numbness", "spasm", "other"],
    lThigh: ["sharp_pain", "dull_pain", "muscle_pain", "swelling", "weakness", "cramps", "bruise", "throbbing_pain", "spasm", "other"],
    rThigh: ["sharp_pain", "dull_pain", "muscle_pain", "swelling", "weakness", "cramps", "bruise", "throbbing_pain", "spasm", "other"],
    lHamstring: ["sharp_pain", "dull_pain", "muscle_pain", "cramps", "spasm", "stiffness", "weakness", "bruise", "other"],
    rHamstring: ["sharp_pain", "dull_pain", "muscle_pain", "cramps", "spasm", "stiffness", "weakness", "bruise", "other"],
    lKnee: ["sharp_pain", "dull_pain", "swelling", "stiffness", "throbbing_pain", "trouble_moving", "injury", "bruise", "other"],
    rKnee: ["sharp_pain", "dull_pain", "swelling", "stiffness", "throbbing_pain", "trouble_moving", "injury", "bruise", "other"],
    lKnee_b: ["sharp_pain", "dull_pain", "swelling", "stiffness", "throbbing_pain", "trouble_moving", "other"],
    rKnee_b: ["sharp_pain", "dull_pain", "swelling", "stiffness", "throbbing_pain", "trouble_moving", "other"],
    lShin: ["sharp_pain", "dull_pain", "swelling", "bruise", "cramps", "throbbing_pain", "cut", "injury", "other"],
    rShin: ["sharp_pain", "dull_pain", "swelling", "bruise", "cramps", "throbbing_pain", "cut", "injury", "other"],
    lCalf: ["sharp_pain", "dull_pain", "cramps", "spasm", "swelling", "muscle_pain", "weakness", "bruise", "other"],
    rCalf: ["sharp_pain", "dull_pain", "cramps", "spasm", "swelling", "muscle_pain", "weakness", "bruise", "other"],
    lFoot: ["sharp_pain", "dull_pain", "swelling", "numbness", "tingling_pain", "throbbing_pain", "cut", "bruise", "rash", "itching", "other"],
    rFoot: ["sharp_pain", "dull_pain", "swelling", "numbness", "tingling_pain", "throbbing_pain", "cut", "bruise", "rash", "itching", "other"],
    lFoot_b: ["sharp_pain", "dull_pain", "swelling", "numbness", "tingling_pain", "throbbing_pain", "cut", "bruise", "other"],
    rFoot_b: ["sharp_pain", "dull_pain", "swelling", "numbness", "tingling_pain", "throbbing_pain", "cut", "bruise", "other"],
};

export const durationOptions = [
    "Started today",
    "1 to 3 days",
    "More than 3 days",
    "1 week or more",
    "Comes and goes",
];

export const REGION_PAIN_TYPES: Record<string, string[]> = {
    head: ["Sharp", "Dull", "Pressure", "Throbbing", "Burning", "Not sure"],
    head_b: ["Sharp", "Dull", "Pressure", "Throbbing", "Burning", "Not sure"],
    neck: ["Sharp", "Dull", "Stiff", "Burning", "Aching", "Not sure"],
    neck_b: ["Sharp", "Dull", "Stiff", "Burning", "Aching", "Not sure"],
    lShoulder: ["Sharp", "Dull", "Aching", "Stiff", "Burning", "Not sure"],
    rShoulder: ["Sharp", "Dull", "Aching", "Stiff", "Burning", "Not sure"],
    lShoulder_b: ["Sharp", "Dull", "Aching", "Stiff", "Burning", "Not sure"],
    rShoulder_b: ["Sharp", "Dull", "Aching", "Stiff", "Burning", "Not sure"],
    chest: ["Sharp", "Pressure", "Tight", "Burning", "Heavy", "Not sure"],
    upperBack: ["Sharp", "Dull", "Aching", "Stiff", "Burning", "Not sure"],
    lowerBack: ["Sharp", "Dull", "Aching", "Stiff", "Burning", "Not sure"],
    abdomen: ["Cramping", "Sharp", "Dull", "Burning", "Pressure", "Not sure"],
    lUpperArm: ["Sharp", "Dull", "Aching", "Throbbing", "Burning", "Not sure"],
    rUpperArm: ["Sharp", "Dull", "Aching", "Throbbing", "Burning", "Not sure"],
    lUpperArm_b: ["Sharp", "Dull", "Aching", "Throbbing", "Burning", "Not sure"],
    rUpperArm_b: ["Sharp", "Dull", "Aching", "Throbbing", "Burning", "Not sure"],
    lForearm: ["Sharp", "Dull", "Aching", "Burning", "Tingling", "Not sure"],
    rForearm: ["Sharp", "Dull", "Aching", "Burning", "Tingling", "Not sure"],
    lForearm_b: ["Sharp", "Dull", "Aching", "Burning", "Tingling", "Not sure"],
    rForearm_b: ["Sharp", "Dull", "Aching", "Burning", "Tingling", "Not sure"],
    lHand: ["Sharp", "Dull", "Burning", "Tingling", "Throbbing", "Not sure"],
    rHand: ["Sharp", "Dull", "Burning", "Tingling", "Throbbing", "Not sure"],
    lHand_b: ["Sharp", "Dull", "Burning", "Tingling", "Throbbing", "Not sure"],
    rHand_b: ["Sharp", "Dull", "Burning", "Tingling", "Throbbing", "Not sure"],
    lHip: ["Sharp", "Dull", "Aching", "Throbbing", "Stiff", "Not sure"],
    rHip: ["Sharp", "Dull", "Aching", "Throbbing", "Stiff", "Not sure"],
    lGlute: ["Sharp", "Dull", "Aching", "Burning", "Throbbing", "Not sure"],
    rGlute: ["Sharp", "Dull", "Aching", "Burning", "Throbbing", "Not sure"],
    lThigh: ["Sharp", "Dull", "Aching", "Cramping", "Throbbing", "Not sure"],
    rThigh: ["Sharp", "Dull", "Aching", "Cramping", "Throbbing", "Not sure"],
    lHamstring: ["Sharp", "Dull", "Aching", "Cramping", "Throbbing", "Not sure"],
    rHamstring: ["Sharp", "Dull", "Aching", "Cramping", "Throbbing", "Not sure"],
    lKnee: ["Sharp", "Dull", "Aching", "Stiff", "Throbbing", "Not sure"],
    rKnee: ["Sharp", "Dull", "Aching", "Stiff", "Throbbing", "Not sure"],
    lKnee_b: ["Sharp", "Dull", "Aching", "Stiff", "Throbbing", "Not sure"],
    rKnee_b: ["Sharp", "Dull", "Aching", "Stiff", "Throbbing", "Not sure"],
    lShin: ["Sharp", "Dull", "Aching", "Cramping", "Burning", "Not sure"],
    rShin: ["Sharp", "Dull", "Aching", "Cramping", "Burning", "Not sure"],
    lCalf: ["Sharp", "Dull", "Aching", "Cramping", "Burning", "Not sure"],
    rCalf: ["Sharp", "Dull", "Aching", "Cramping", "Burning", "Not sure"],
    lFoot: ["Sharp", "Dull", "Burning", "Tingling", "Throbbing", "Not sure"],
    rFoot: ["Sharp", "Dull", "Burning", "Tingling", "Throbbing", "Not sure"],
    lFoot_b: ["Sharp", "Dull", "Burning", "Tingling", "Throbbing", "Not sure"],
    rFoot_b: ["Sharp", "Dull", "Burning", "Tingling", "Throbbing", "Not sure"],
};

export const DEFAULT_PAIN_TYPES = ["Sharp", "Dull", "Aching", "Throbbing", "Burning", "Not sure"];