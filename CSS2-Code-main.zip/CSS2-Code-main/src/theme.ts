// ─── THEME ────────────────────────────────────────────────────────────────────
export const BG = "#f8f7ff";
export const CARD = "#ffffff";
export const BORDER = "#e2e0f0";
export const IDLE_FILL = "#d8b4fe";
export const IDLE_STROKE = "#a855f7";
export const ACTIVE_COLOR = "#7c3aed";
export const ACTIVE_STROKE = "#5b21b6";
export const ACCENT = "#7c3aed";
export const TEXT = "#1e1b4b";
export const MUTED = "#8b80b3";