import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ACCENT, BG, BORDER, CARD, MUTED, TEXT } from "../theme";

interface Region { id: string; label: string }
interface Symptom { id: string; label: string }

interface Props {
    selectedRegions: Region[];
    selectedSymptoms: Symptom[];
    selectedPainTypes?: string[];
    duration?: string | null;
    onReset: () => void;
    onBack: () => void;
}

export default function SubmittedView({ selectedRegions, selectedSymptoms, selectedPainTypes, duration, onReset, onBack }: Props) {
    const sections = [
        { label: "Body Areas", items: selectedRegions.map(r => r.label) },
        { label: "Symptoms", items: selectedSymptoms.map(s => s.label) },
        ...(selectedPainTypes?.length ? [{ label: "Pain Type", items: selectedPainTypes }] : []),
    ];

    return (
        <div style={{ width: "100%", height: "100vh", background: BG, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Segoe UI', sans-serif" }}>
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                style={{
                    background: CARD, borderRadius: 20, padding: 40,
                    maxWidth: 540, width: "90%", color: TEXT,
                    border: `1px solid ${BORDER}`,
                    overflowY: "auto", maxHeight: "90vh",
                }}
            >
                <div style={{ fontSize: 52, textAlign: "center" }}>✅</div>
                <h2 style={{ textAlign: "center", color: ACCENT, margin: "12px 0 8px", fontSize: 22 }}>Report Submitted</h2>
                <p style={{ color: MUTED, textAlign: "center", fontSize: 14, marginBottom: 24 }}>Sent to the health team for review.</p>

                {sections.map(s => s.items.length > 0 && (
                    <div key={s.label} style={{ marginBottom: 14 }}>
                        <p style={{ margin: "0 0 7px", fontSize: 11, color: MUTED, textTransform: "uppercase", letterSpacing: 1, fontWeight: 600 }}>{s.label}</p>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
                            {s.items.map(item => (
                                <span key={item} style={{ background: "#ede9fe", color: ACCENT, borderRadius: 20, padding: "5px 13px", fontSize: 13, fontWeight: 600, border: "1px solid #c4b5fd" }}>{item}</span>
                            ))}
                        </div>
                    </div>
                ))}

                {duration && (
                    <div style={{ marginBottom: 24 }}>
                        <p style={{ margin: "0 0 7px", fontSize: 11, color: MUTED, textTransform: "uppercase", letterSpacing: 1, fontWeight: 600 }}>Duration</p>
                        <span style={{ background: "#ede9fe", color: ACCENT, borderRadius: 20, padding: "5px 13px", fontSize: 13, fontWeight: 600, border: "1px solid #c4b5fd" }}>{duration}</span>
                    </div>
                )}

                <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 8 }}>
                    <button onClick={onReset} style={{ width: "100%", padding: "13px 0", background: ACCENT, color: "#fff", border: "none", borderRadius: 12, fontSize: 15, cursor: "pointer", fontWeight: 600 }}>
                        Start New Report
                    </button>
                    <button onClick={onBack} style={{ width: "100%", padding: "13px 0", background: "transparent", color: MUTED, border: `1px solid ${BORDER}`, borderRadius: 12, fontSize: 14, cursor: "pointer" }}>
                        ← Back to Role Select
                    </button>
                </div>
            </motion.div>
        </div>
    );
}