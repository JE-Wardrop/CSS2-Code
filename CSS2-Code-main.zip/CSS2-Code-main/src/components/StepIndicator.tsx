import { ACCENT, MUTED } from "../theme";

const STEPS = ["Body", "Symptoms", "Pain"];

export default function StepIndicator({ currentStep }: { currentStep: number }) {
    return (
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            {STEPS.map((label, i) => {
                const stepNum = i + 1;
                const done = stepNum < currentStep;
                const active = stepNum === currentStep;
                return (
                    <div key={label} style={{ display: "flex", alignItems: "center", gap: 4 }}>
                        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
                            <div style={{
                                width: 24, height: 24, borderRadius: "50%",
                                background: done ? ACCENT : active ? ACCENT : "#e5e7eb",
                                color: done || active ? "#fff" : MUTED,
                                fontSize: 11, fontWeight: 700,
                                display: "flex", alignItems: "center", justifyContent: "center",
                                transition: "all 0.2s",
                                opacity: done ? 0.7 : 1,
                            }}>
                                {done ? "✓" : stepNum}
                            </div>
                            <span style={{ fontSize: 10, color: active ? ACCENT : MUTED, fontWeight: active ? 700 : 400, whiteSpace: "nowrap" }}>
                                {label}
                            </span>
                        </div>
                        {i < STEPS.length - 1 && (
                            <div style={{
                                width: 18, height: 2, borderRadius: 1, marginBottom: 12,
                                background: done ? ACCENT : "#e5e7eb",
                                transition: "background 0.2s",
                            }} />
                        )}
                    </div>
                );
            })}
        </div>
    );
}