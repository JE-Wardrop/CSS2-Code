import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

export default function EmergencyButton() {
    const [open, setOpen] = useState(false);
    const [sent, setSent] = useState(false);

    const handleAlert = () => {
        setSent(true);
        setTimeout(() => { setSent(false); setOpen(false); }, 3000);
    };

    return (
        <>
            <AnimatePresence>
                {open && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        onClick={() => setOpen(false)}
                        style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", zIndex: 998 }}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {open && (
                    <motion.div
                        initial={{ opacity: 0, y: 24, scale: 0.97 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 24, scale: 0.97 }}
                        transition={{ type: "spring", stiffness: 320, damping: 28 }}
                        style={{
                            position: "fixed", bottom: 82, right: 20, left: 20,
                            maxWidth: 340, margin: "0 auto",
                            background: "#fff", borderRadius: 18,
                            boxShadow: "0 12px 48px rgba(0,0,0,0.22)",
                            zIndex: 999, overflow: "hidden",
                            fontFamily: "'Segoe UI', system-ui, sans-serif",
                        }}
                    >
                        {sent ? (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                                style={{ padding: "40px 28px", textAlign: "center", background: "#f0fdf4" }}
                            >
                                <div style={{
                                    width: 52, height: 52, borderRadius: "50%",
                                    background: "#dcfce7", border: "2px solid #86efac",
                                    display: "flex", alignItems: "center", justifyContent: "center",
                                    margin: "0 auto 16px",
                                }}>
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                        <polyline points="20 6 9 17 4 12" />
                                    </svg>
                                </div>
                                <div style={{ fontSize: 20, fontWeight: 800, color: "#15803d", marginBottom: 6 }}>Alert Sent</div>
                                <div style={{ fontSize: 14, color: "#6b7280" }}>Staff have been notified.</div>
                            </motion.div>
                        ) : (
                            <div style={{ padding: 24, textAlign: "center" }}>
                                <div style={{
                                    width: 52, height: 52, borderRadius: "50%",
                                    background: "#fee2e2", border: "2px solid #fca5a5",
                                    display: "flex", alignItems: "center", justifyContent: "center",
                                    margin: "0 auto 16px",
                                }}>
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                        <circle cx="12" cy="12" r="10" />
                                        <line x1="12" y1="8" x2="12" y2="12" />
                                        <line x1="12" y1="16" x2="12.01" y2="16" />
                                    </svg>
                                </div>

                                <div style={{ fontSize: 19, fontWeight: 800, color: "#111", marginBottom: 6 }}>
                                    Call for Help?
                                </div>
                                <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 24, lineHeight: 1.5 }}>
                                    This will alert healthcare staff immediately.
                                </div>

                                <button onClick={handleAlert}
                                    style={{
                                        width: "100%", padding: "14px 0",
                                        background: "#dc2626", color: "#fff",
                                        border: "none", borderRadius: 12,
                                        fontSize: 15, fontWeight: 800,
                                        cursor: "pointer", letterSpacing: 0.5,
                                        marginBottom: 10,
                                    }}>
                                    Yes, Alert Staff
                                </button>
                                <button onClick={() => setOpen(false)}
                                    style={{
                                        width: "100%", padding: "12px 0",
                                        background: "#f3f4f6", color: "#374151",
                                        border: "none", borderRadius: 12,
                                        fontSize: 14, fontWeight: 600,
                                        cursor: "pointer",
                                    }}>
                                    Cancel
                                </button>
                            </div>
                        )}
                    </motion.div>
                )}
            </AnimatePresence>

            <motion.button
                whileTap={{ scale: 0.93 }}
                onClick={() => setOpen(o => !o)}
                animate={{
                    boxShadow: open
                        ? "0 4px 20px rgba(220,38,38,0.45)"
                        : ["0 4px 20px rgba(220,38,38,0.45)", "0 4px 28px rgba(220,38,38,0.75)", "0 4px 20px rgba(220,38,38,0.45)"],
                }}
                transition={{ repeat: Infinity, duration: 2 }}
                style={{
                    position: "fixed", bottom: 20, right: 20, zIndex: 1000,
                    background: open ? "#b91c1c" : "#dc2626",
                    color: "#fff", border: "none", borderRadius: 50,
                    padding: "14px 26px", fontSize: 14, fontWeight: 800,
                    cursor: "pointer", display: "flex", alignItems: "center", gap: 8,
                    letterSpacing: 1.4, textTransform: "uppercase",
                    fontFamily: "'Segoe UI', system-ui, sans-serif",
                }}
            >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
                Emergency
            </motion.button>
        </>
    );
}