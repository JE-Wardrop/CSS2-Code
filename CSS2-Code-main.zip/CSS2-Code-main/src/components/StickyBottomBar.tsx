import { AnimatePresence, motion } from "framer-motion";
import { ACCENT, BORDER, CARD, MUTED } from "../theme";

interface Props {
    canSubmit: boolean;
    showClear: boolean;
    onSubmit: () => void;
    onClear: () => void;
    submitLabel?: string;
}

export default function StickyBottomBar({ canSubmit, showClear, onSubmit, onClear, submitLabel = "Submit →" }: Props) {
    return (
        <div style={{
            position: "fixed", bottom: 0, left: 0, right: 0,
            background: CARD, borderTop: `1px solid ${BORDER}`,
            padding: "12px 18px",
            display: "flex", gap: 10, alignItems: "center",
        }}>
            <AnimatePresence>
                {showClear && (
                    <motion.button
                        key="clear"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClear}
                        style={{
                            padding: "10px 16px", background: "transparent",
                            color: MUTED, border: `1px solid ${BORDER}`,
                            borderRadius: 12, fontSize: 13, cursor: "pointer",
                            whiteSpace: "nowrap", flexShrink: 0,
                        }}
                    >
                        Clear
                    </motion.button>
                )}
            </AnimatePresence>

            <div style={{ flex: 1 }} />

            <button
                onClick={() => canSubmit && onSubmit()}
                disabled={!canSubmit}
                style={{
                    padding: "12px 28px",
                    background: canSubmit ? ACCENT : "#e5e1f8",
                    color: canSubmit ? "#fff" : "#b8aee0",
                    border: "none", borderRadius: 12,
                    fontSize: 15, fontWeight: 700,
                    cursor: canSubmit ? "pointer" : "not-allowed",
                    flexShrink: 0, transition: "all 0.15s",
                }}
            >
                {submitLabel}
            </button>
        </div>
    );
}