import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate, useLocation } from "react-router-dom";
import { ACCENT, BG, BORDER, CARD, MUTED, TEXT } from "../theme";
import StepIndicator from "../components/StepIndicator";
import StickyBottomBar from "../components/StickyBottomBar";

const SAFETY_QUESTIONS = [
    {
        id: "self_harm",
        question: "Are you having thoughts of hurting yourself?",
        flag: true,
    },
    {
        id: "harm_others",
        question: "Are you worried about being hurt by someone else?",
        flag: true,
    },
    {
        id: "feel_safe",
        question: "Do you feel safe where you are right now?",
        flag: false, // "No" here is the flag
        invertFlag: true,
    },
    {
        id: "medication",
        question: "Have you taken more medication than prescribed, or substances you shouldn't have?",
        flag: true,
    },
    {
        id: "mental_health",
        question: "Are you feeling very anxious, confused, or hearing/seeing things that aren't there?",
        flag: true,
    },
];

type Answers = Record<string, "yes" | "no" | null>;

export default function SafetyPage() {
    const navigate = useNavigate();
    const location = useLocation();
    const passedRegions = location.state?.selectedRegions ?? [];
    const passedSymptoms = location.state?.selectedSymptoms ?? [];

    const [answers, setAnswers] = useState<Answers>(
        Object.fromEntries(SAFETY_QUESTIONS.map(q => [q.id, null]))
    );
    const [showAlert, setShowAlert] = useState(false);

    const setAnswer = (id: string, val: "yes" | "no") => {
        setAnswers(prev => ({ ...prev, [id]: val }));
    };

    const answered = Object.values(answers).every(v => v !== null);

    const hasSafetyConcern = SAFETY_QUESTIONS.some(q => {
        const ans = answers[q.id];
        if (ans === null) return false;
        return q.invertFlag ? ans === "no" : ans === "yes" && q.flag;
    });

    const handleNext = () => {
        if (hasSafetyConcern) {
            setShowAlert(true);
        } else {
            navigate("/pain", { state: { selectedRegions: passedRegions, selectedSymptoms: passedSymptoms, safetyAnswers: answers } });
        }
    };

    const handleContinueAnyway = () => {
        navigate("/pain", { state: { selectedRegions: passedRegions, selectedSymptoms: passedSymptoms, safetyAnswers: answers, safetyConcern: true } });
    };

    return (
        <div style={{ width: "100%", height: "100vh", background: BG, fontFamily: "'Segoe UI', sans-serif", display: "flex", flexDirection: "column", overflow: "hidden", color: TEXT }}>

            {/* Header */}
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 20px", background: CARD, borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
                <button onClick={() => navigate(-1)} style={{ background: "none", border: "none", color: MUTED, fontSize: 24, cursor: "pointer", lineHeight: 1, padding: "0 4px" }}>‹</button>
                <span style={{ color: MUTED, fontSize: 13, marginLeft: 2 }}>Patient Portal</span>
                <div style={{ marginLeft: "auto" }}><StepIndicator currentStep={3} /></div>
            </div>

            {/* Content */}
            <div style={{ flex: 1, overflowY: "auto", padding: "20px 20px 110px" }}>
                <div style={{ marginBottom: 20 }}>
                    <h1 style={{ margin: "0 0 6px", fontSize: 22, fontWeight: 800, color: TEXT }}>Safety check</h1>
                    <p style={{ margin: 0, color: MUTED, fontSize: 14 }}>
                        Please answer honestly. Your answers are seen only by health staff.
                    </p>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                    {SAFETY_QUESTIONS.map((q, i) => (
                        <motion.div
                            key={q.id}
                            initial={{ opacity: 0, y: 12 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.07 }}
                            style={{
                                background: CARD, borderRadius: 16, padding: "16px 18px",
                                border: `1.5px solid ${answers[q.id] !== null ? ACCENT + "55" : BORDER}`,
                            }}
                        >
                            <p style={{ margin: "0 0 12px", fontSize: 15, fontWeight: 600, color: TEXT, lineHeight: 1.4 }}>
                                {q.question}
                            </p>
                            <div style={{ display: "flex", gap: 8 }}>
                                {(["yes", "no"] as const).map(opt => (
                                    <button
                                        key={opt}
                                        onClick={() => setAnswer(q.id, opt)}
                                        style={{
                                            flex: 1, padding: "10px 0", borderRadius: 12, fontSize: 14, fontWeight: 700,
                                            border: `2px solid ${answers[q.id] === opt ? ACCENT : BORDER}`,
                                            background: answers[q.id] === opt ? "#ede9fe" : BG,
                                            color: answers[q.id] === opt ? ACCENT : MUTED,
                                            cursor: "pointer", transition: "all 0.12s",
                                        }}
                                    >
                                        {opt === "yes" ? "Yes" : "No"}
                                    </button>
                                ))}
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>

            {/* Safety concern modal */}
            <AnimatePresence>
                {showAlert && (
                    <>
                        <motion.div
                            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                            style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", zIndex: 50 }}
                        />
                        <motion.div
                            initial={{ opacity: 0, scale: 0.94, y: 30 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.94, y: 30 }}
                            style={{
                                position: "fixed", bottom: 0, left: 0, right: 0,
                                background: "#fff", borderRadius: "20px 20px 0 0",
                                padding: "28px 24px 36px",
                                zIndex: 51, maxWidth: 480, margin: "0 auto",
                            }}
                        >
                            <div style={{ fontSize: 36, textAlign: "center", marginBottom: 12 }}>🧡</div>
                            <h2 style={{ textAlign: "center", margin: "0 0 10px", fontSize: 20, fontWeight: 800, color: TEXT }}>
                                We want to make sure you're safe
                            </h2>
                            <p style={{ color: MUTED, fontSize: 14, textAlign: "center", margin: "0 0 22px", lineHeight: 1.6 }}>
                                Based on your answers, a staff member will check on you soon. You can still finish this health report, or let staff know right away.
                            </p>
                            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                                <button
                                    onClick={() => { setShowAlert(false); /* In a real app: trigger alert to staff */ }}
                                    style={{ padding: "14px", borderRadius: 12, background: "#fee2e2", color: "#991b1b", border: "none", fontSize: 15, fontWeight: 800, cursor: "pointer" }}
                                >
                                    🚨 Alert staff right now
                                </button>
                                <button
                                    onClick={handleContinueAnyway}
                                    style={{ padding: "14px", borderRadius: 12, background: "#ede9fe", color: ACCENT, border: "none", fontSize: 15, fontWeight: 700, cursor: "pointer" }}
                                >
                                    Continue with health report
                                </button>
                                <button
                                    onClick={() => setShowAlert(false)}
                                    style={{ padding: "10px", borderRadius: 12, background: "none", color: MUTED, border: `1px solid ${BORDER}`, fontSize: 14, cursor: "pointer" }}
                                >
                                    Go back
                                </button>
                            </div>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>

            <StickyBottomBar
                canSubmit={answered}
                showClear={Object.values(answers).some(v => v !== null)}
                onClear={() => setAnswers(Object.fromEntries(SAFETY_QUESTIONS.map(q => [q.id, null])))}
                onSubmit={handleNext}
                submitLabel="Next →"
            />
        </div>
    );
}