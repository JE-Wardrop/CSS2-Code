import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ACCENT, BG, BORDER, CARD, MUTED, TEXT } from "../theme";

export default function PlaceholderPage({ role, icon }) {
    const navigate = useNavigate();
    return (
        <div style={{ width: "100%", height: "100vh", background: BG, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: "'Segoe UI', sans-serif" }}>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                style={{ background: CARD, borderRadius: 20, padding: 48, maxWidth: 440, width: "90%", textAlign: "center", border: `1px solid ${BORDER}`, boxShadow: "0 8px 32px rgba(124,58,237,0.08)" }}>
                <div style={{ fontSize: 56, marginBottom: 16 }}>{icon}</div>
                <h2 style={{ margin: "0 0 8px", fontSize: 22, fontWeight: 800, color: TEXT }}>{role} Portal</h2>
                <p style={{ color: MUTED, fontSize: 15, marginBottom: 32 }}>This section is coming soon.<br />Check back later!</p>
                <button onClick={() => navigate("/")}
                    style={{ padding: "12px 32px", background: ACCENT, color: "#fff", border: "none", borderRadius: 12, fontSize: 15, fontWeight: 600, cursor: "pointer" }}>
                    ← Back to Role Select
                </button>
            </motion.div>
        </div>
    );
}