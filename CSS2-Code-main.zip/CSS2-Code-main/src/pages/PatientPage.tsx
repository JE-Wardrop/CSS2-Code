import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { REGIONS_FRONT, REGIONS_BACK, FRONT_DETAILS, BACK_DETAILS } from "../constants";
import { ACCENT, ACTIVE_COLOR, ACTIVE_STROKE, BG, BORDER, CARD, IDLE_FILL, IDLE_STROKE, MUTED, TEXT } from "../theme";
import StepIndicator from "../components/StepIndicator";

// ─── BODY DIAGRAM ─────────────────────────────────────────────────────────────
function BodyDiagram({ regions, selected, onToggle, isFront }) {
    const details = isFront ? FRONT_DETAILS : BACK_DETAILS;
    return (
        <svg viewBox="0 0 400 545" style={{ height: "min(68vh, 560px)", width: "auto", display: "block", filter: "drop-shadow(0 4px 16px rgba(124,58,237,0.12))" }}>
            <defs>
                <radialGradient id="bg2" cx="50%" cy="45%" r="50%">
                    <stop offset="0%" stopColor="#c4b5fd" stopOpacity="0.25" />
                    <stop offset="100%" stopColor="transparent" stopOpacity="0" />
                </radialGradient>
                <filter id="glow2">
                    <feGaussianBlur stdDeviation="3" result="blur" />
                    <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                </filter>
            </defs>
            <ellipse cx="200" cy="290" rx="145" ry="248" fill="url(#bg2)" />

            {regions.map(r => {
                const active = selected.has(r.id);
                return (
                    <motion.path
                        key={r.id} d={r.d}
                        fill={active ? ACTIVE_COLOR : IDLE_FILL}
                        stroke={active ? ACTIVE_STROKE : IDLE_STROKE}
                        strokeWidth={active ? 2.5 : 1.2}
                        strokeLinejoin="round"
                        style={{ cursor: "pointer" }}
                        onClick={() => onToggle(r.id)}
                        animate={{ fill: active ? ACTIVE_COLOR : IDLE_FILL }}
                        whileHover={{ filter: "brightness(1.15)", scale: 1.04 }}
                        whileTap={{ scale: 0.94 }}
                        transition={{ duration: 0.15 }}
                        filter={active ? "url(#glow2)" : undefined}
                    />
                );
            })}

            <g style={{ pointerEvents: "none" }} dangerouslySetInnerHTML={{ __html: details }} />
        </svg>
    );
}

// ─── FLIP TOGGLE ──────────────────────────────────────────────────────────────
function FlipToggle({ isFront, onFlip }) {
    return (
        <div style={{ display: "flex", alignItems: "center", gap: 6, background: "#ede9fe", borderRadius: 20, padding: "4px 6px", border: `1px solid #c4b5fd` }}>
            <button
                onClick={() => !isFront && onFlip()}
                style={{
                    padding: "5px 14px", borderRadius: 16, fontSize: 12, fontWeight: isFront ? 700 : 400,
                    background: isFront ? ACCENT : "transparent",
                    color: isFront ? "#fff" : MUTED,
                    border: "none", cursor: isFront ? "default" : "pointer", transition: "all 0.15s",
                }}
            >
                Front
            </button>
            <button
                onClick={() => isFront && onFlip()}
                style={{
                    padding: "5px 14px", borderRadius: 16, fontSize: 12, fontWeight: !isFront ? 700 : 400,
                    background: !isFront ? ACCENT : "transparent",
                    color: !isFront ? "#fff" : MUTED,
                    border: "none", cursor: !isFront ? "default" : "pointer", transition: "all 0.15s",
                }}
            >
                Back
            </button>
        </div>
    );
}

// ─── PATIENT PAGE ─────────────────────────────────────────────────────────────
export default function PatientPage() {
    const navigate = useNavigate();
    const [selected, setSelected] = useState(new Set<string>());
    const [isFront, setIsFront] = useState(true);

    const toggle = (id: string) => setSelected(prev => {
        const next = new Set(prev);
        next.has(id) ? next.delete(id) : next.add(id);
        return next;
    });

    const allRegions = [...REGIONS_FRONT, ...REGIONS_BACK];
    const activeRegions = isFront ? REGIONS_FRONT : REGIONS_BACK;
    const selectedRegions = allRegions.filter(r => selected.has(r.id));

    const handleNext = () => {
        if (selected.size > 0) {
            navigate("/symptoms", { state: { selectedRegions } });
        }
    };

    return (
        <div style={{ width: "100%", height: "100vh", background: BG, fontFamily: "'Segoe UI', sans-serif", display: "flex", flexDirection: "column", overflow: "hidden", color: TEXT }}>
            {/* Header */}
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 24px", background: CARD, borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
                <button onClick={() => navigate("/")} style={{ background: "none", border: "none", color: MUTED, fontSize: 22, cursor: "pointer", lineHeight: 1, padding: "0 4px" }}>‹</button>
                <span style={{ color: MUTED, fontSize: 13, marginLeft: 4 }}>Patient Portal</span>
                {/* Step indicator */}
                <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
                    <StepIndicator currentStep={1} />
                </div>
            </div>

            <div style={{ flex: 1, display: "flex", flexDirection: "row", overflow: "hidden" }}>
                {/* Left: Body Diagram */}
                <div style={{ flex: "0 0 auto", width: "54%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "16px", borderRight: `1px solid ${BORDER}`, background: "#faf9ff" }}>
                    <div style={{ width: "100%", maxWidth: 340, marginBottom: 10, display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
                        <div>
                            <h1 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 700, color: TEXT }}>Where does it hurt?</h1>
                            <p style={{ margin: 0, color: MUTED, fontSize: 13 }}>Tap any area to select or deselect.</p>
                        </div>
                        <FlipToggle isFront={isFront} onFlip={() => setIsFront(f => !f)} />
                    </div>
                    <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", width: "100%", position: "relative" }}>
                        <AnimatePresence mode="wait">
                            <motion.div
                                key={isFront ? "front" : "back"}
                                initial={{ opacity: 0, rotateY: isFront ? -30 : 30, scale: 0.96 }}
                                animate={{ opacity: 1, rotateY: 0, scale: 1 }}
                                exit={{ opacity: 0, rotateY: isFront ? 30 : -30, scale: 0.96 }}
                                transition={{ duration: 0.25 }}
                                style={{ display: "flex", alignItems: "center", justifyContent: "center" }}
                            >
                                <BodyDiagram
                                    regions={activeRegions}
                                    selected={selected}
                                    onToggle={toggle}
                                    isFront={isFront}
                                />
                            </motion.div>
                        </AnimatePresence>
                    </div>
                </div>

                {/* Right: Selection Panel */}
                <div style={{ flex: 1, display: "flex", flexDirection: "column", padding: "28px 28px", overflowY: "auto", background: CARD }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
                        <div>
                            <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: TEXT }}>Selected Areas</h2>
                            <p style={{ margin: "3px 0 0", color: MUTED, fontSize: 13 }}>Tap a chip to remove it</p>
                        </div>

                    </div>

                    <div style={{ flex: 1, minHeight: 0 }}>
                        {selected.size === 0 ? (
                            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: 160, color: MUTED, textAlign: "center", gap: 10 }}>
                                <div style={{ fontSize: 36, opacity: 0.35 }}>👆</div>
                                <p style={{ margin: 0, fontSize: 14 }}>No areas selected yet.<br />Tap the body diagram on the left.</p>
                            </div>
                        ) : (
                            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignContent: "flex-start" }}>
                                <AnimatePresence>
                                    {selectedRegions.map(r => (
                                        <motion.button key={r.id} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }}
                                            onClick={() => toggle(r.id)}
                                            style={{ display: "flex", alignItems: "center", gap: 6, background: "#ede9fe", color: ACCENT, borderRadius: 20, padding: "8px 14px 8px 16px", fontSize: 13, fontWeight: 600, border: `1px solid #c4b5fd`, cursor: "pointer" }}>
                                            {r.label} <span style={{ fontSize: 16, lineHeight: 1, opacity: 0.6 }}>×</span>
                                        </motion.button>
                                    ))}
                                </AnimatePresence>
                            </div>
                        )}
                    </div>

                    <div style={{ borderTop: `1px solid ${BORDER}`, margin: "18px 0" }} />

                    {/* All Regions Quick-Select */}
                    <div style={{ marginBottom: 18 }}>
                        <p style={{ margin: "0 0 10px", fontSize: 11, color: MUTED, textTransform: "uppercase", letterSpacing: 1, fontWeight: 600 }}>
                            {isFront ? "Front Regions" : "Back Regions"}
                        </p>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                            {activeRegions.map(r => {
                                const active = selected.has(r.id);
                                return (
                                    <button key={r.id} onClick={() => toggle(r.id)}
                                        style={{ padding: "5px 11px", borderRadius: 14, fontSize: 12, fontWeight: active ? 700 : 400, background: active ? "#ede9fe" : "#f5f3ff", color: active ? ACCENT : MUTED, border: `1px solid ${active ? "#c4b5fd" : BORDER}`, cursor: "pointer", transition: "all 0.12s" }}>
                                        {r.label}
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Actions */}
                    <div style={{ display: "flex", gap: 10 }}>
                        <button
                            onClick={handleNext}
                            disabled={selected.size === 0}
                            style={{ flex: 1, padding: "14px 0", background: selected.size > 0 ? ACCENT : "#e5e1f8", color: selected.size > 0 ? "#fff" : "#b8aee0", border: "none", borderRadius: 12, fontSize: 15, fontWeight: 700, cursor: selected.size > 0 ? "pointer" : "not-allowed", transition: "all 0.15s" }}>
                            Next: Describe Symptoms →
                        </button>
                        {selected.size > 0 && (
                            <button onClick={() => setSelected(new Set())}
                                style={{ padding: "14px 18px", background: "transparent", color: MUTED, border: `1px solid ${BORDER}`, borderRadius: 12, fontSize: 13, cursor: "pointer", whiteSpace: "nowrap" }}>
                                Clear All
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}