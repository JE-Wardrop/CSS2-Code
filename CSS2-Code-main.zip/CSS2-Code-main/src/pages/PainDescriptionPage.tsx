import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useNavigate, useLocation } from "react-router-dom";
import { ACCENT, BG, BORDER, CARD, MUTED, TEXT } from "../theme";
import { DEFAULT_PAIN_TYPES, durationOptions, REGION_PAIN_TYPES } from "../constants";
import StepIndicator from "../components/StepIndicator";
import SubmittedView from "../components/SubmittedView";
import StickyBottomBar from "../components/StickyBottomBar";

// Pain scale labels
const PAIN_SCALE = [
    { val: 1, label: "Very mild", color: "#86efac" },
    { val: 2, label: "Mild", color: "#86efac" },
    { val: 3, label: "Uncomfortable", color: "#fde68a" },
    { val: 4, label: "Uncomfortable", color: "#fde68a" },
    { val: 5, label: "Moderate", color: "#fde68a" },
    { val: 6, label: "Moderate", color: "#fdba74" },
    { val: 7, label: "Severe", color: "#fdba74" },
    { val: 8, label: "Very severe", color: "#fca5a5" },
    { val: 9, label: "Very severe", color: "#fca5a5" },
    { val: 10, label: "Worst possible", color: "#f87171" },
];

function PainChip({ label, active, onToggle }: { label: string; active: boolean; onToggle: () => void }) {
    return (
        <motion.button
            layout whileTap={{ scale: 0.95 }} onClick={onToggle}
            style={{
                flex: "1 1 calc(33% - 8px)", minHeight: 56,
                display: "flex", alignItems: "center", justifyContent: "space-between",
                gap: 10, padding: "0 16px", borderRadius: 14,
                border: `2px solid ${active ? "#7c3aed" : BORDER}`,
                background: active ? "#ede9fe" : CARD,
                color: active ? ACCENT : TEXT,
                fontWeight: active ? 700 : 500, fontSize: 15,
                cursor: "pointer", transition: "border-color 0.15s, background 0.15s",
            }}
        >
            <span>{label}</span>
            <AnimatePresence>
                {active && (
                    <motion.span
                        initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }}
                        style={{ width: 22, height: 22, borderRadius: "50%", background: "#7c3aed", color: "#fff", fontSize: 11, fontWeight: 800, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}
                    >✓</motion.span>
                )}
            </AnimatePresence>
        </motion.button>
    );
}

function DurationChip({ label, active, onSelect }: { label: string; active: boolean; onSelect: () => void }) {
    return (
        <motion.button
            whileTap={{ scale: 0.95 }} onClick={onSelect}
            style={{
                flex: "1 1 calc(33% - 8px)", minHeight: 56,
                display: "flex", alignItems: "center", justifyContent: "space-between",
                gap: 10, padding: "0 16px", borderRadius: 14,
                border: `2px solid ${active ? "#7c3aed" : BORDER}`,
                background: active ? "#ede9fe" : CARD,
                color: active ? ACCENT : TEXT,
                fontWeight: active ? 700 : 500, fontSize: 15,
                cursor: "pointer", transition: "all 0.15s",
            }}
        >
            <span>{label}</span>
            <AnimatePresence>
                {active && (
                    <motion.span
                        initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }}
                        style={{ width: 22, height: 22, borderRadius: "50%", background: "#7c3aed", color: "#fff", fontSize: 11, fontWeight: 800, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}
                    >✓</motion.span>
                )}
            </AnimatePresence>
        </motion.button>
    );
}

export default function PainDescriptionPage() {
    const navigate = useNavigate();
    const location = useLocation();
    const passedRegions: { id: string; label: string }[] = location.state?.selectedRegions ?? [];
    const passedSymptoms: { id: string; label: string }[] = location.state?.selectedSymptoms ?? [];

    const [selectedPainTypes, setSelectedPainTypes] = useState(new Set<string>());
    const [duration, setDuration] = useState<string | null>(null);
    const [painScore, setPainScore] = useState<number>(5);
    const [submitted, setSubmitted] = useState(false);

    const painTypes = Array.from(
        new Set(passedRegions.length > 0
            ? passedRegions.flatMap(r => REGION_PAIN_TYPES[r.id] ?? DEFAULT_PAIN_TYPES)
            : DEFAULT_PAIN_TYPES)
    );

    const togglePainType = (pt: string) => setSelectedPainTypes(prev => {
        const next = new Set(prev);
        next.has(pt) ? next.delete(pt) : next.add(pt);
        return next;
    });

    const canSubmit = selectedPainTypes.size > 0 && duration !== null;
    const currentScale = PAIN_SCALE[painScore - 1];

    if (submitted) {
        return (
            <SubmittedView
                selectedRegions={passedRegions}
                selectedSymptoms={passedSymptoms}
                selectedPainTypes={Array.from(selectedPainTypes)}
                duration={duration}
                painScore={painScore}
                onReset={() => { setSelectedPainTypes(new Set()); setDuration(null); setSubmitted(false); navigate("/patient"); }}
                onBack={() => navigate("/")}
            />
        );
    }

    return (
        <div style={{ width: "100%", height: "100vh", background: BG, fontFamily: "'Segoe UI', sans-serif", display: "flex", flexDirection: "column", overflow: "hidden", color: TEXT }}>

            {/* Header */}
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 20px", background: CARD, borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
                <button onClick={() => navigate(-1)} style={{ background: "none", border: "none", color: MUTED, fontSize: 24, cursor: "pointer", lineHeight: 1, padding: "0 4px" }}>‹</button>
                <span style={{ color: MUTED, fontSize: 13, marginLeft: 2 }}>Patient Portal</span>
                <div style={{ marginLeft: "auto" }}><StepIndicator currentStep={3} /></div>
            </div>



            <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>

                {/* Pain scale */}
                <div style={{ padding: "18px 20px 14px", borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
                    <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 800, color: TEXT }}>How bad is the pain?</h2>
                    <p style={{ margin: "0 0 14px", color: MUTED, fontSize: 14 }}>Slide to rate from 1 (very mild) to 10 (worst possible)</p>
                    <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                        <input
                            type="range" min={1} max={10} step={1} value={painScore}
                            onChange={e => setPainScore(Number(e.target.value))}
                            style={{ flex: 1 }}
                        />
                        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", minWidth: 60 }}>
                            <div style={{
                                width: 48, height: 48, borderRadius: "50%",
                                background: currentScale.color,
                                display: "flex", alignItems: "center", justifyContent: "center",
                                fontSize: 20, fontWeight: 800, color: "#1f2937",
                                transition: "background 0.2s",
                            }}>
                                {painScore}
                            </div>
                            <span style={{ fontSize: 11, color: MUTED, marginTop: 3, textAlign: "center" }}>{currentScale.label}</span>
                        </div>
                    </div>
                    {/* Scale labels */}
                    <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
                        <span style={{ fontSize: 11, color: MUTED }}>1 – Very mild</span>
                        <span style={{ fontSize: 11, color: MUTED }}>10 – Worst</span>
                    </div>
                </div>

                {/* Pain type + duration sections */}
                <div style={{ flex: 1, overflowY: "auto" }}>

                    <div style={{ padding: "16px 20px 14px", borderBottom: `1px solid ${BORDER}` }}>
                        <h2 style={{ margin: "0 0 4px", fontSize: 18, fontWeight: 800, color: TEXT }}>How does it feel?</h2>
                        <p style={{ margin: "0 0 12px", color: MUTED, fontSize: 14 }}>Select all that apply</p>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                            {painTypes.map(pt => (
                                <PainChip key={pt} label={pt} active={selectedPainTypes.has(pt)} onToggle={() => togglePainType(pt)} />
                            ))}
                        </div>
                    </div>

                    <div style={{ padding: "16px 20px 110px" }}>
                        <h2 style={{ margin: "0 0 4px", fontSize: 18, fontWeight: 800, color: TEXT }}>How long have you had this?</h2>
                        <p style={{ margin: "0 0 12px", color: MUTED, fontSize: 14 }}>Choose one</p>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                            {durationOptions.map(opt => (
                                <DurationChip key={opt} label={opt} active={duration === opt} onSelect={() => setDuration(opt)} />
                            ))}
                        </div>
                    </div>

                </div>
            </div>

            <StickyBottomBar
                canSubmit={canSubmit}
                showClear={selectedPainTypes.size > 0 || duration !== null}
                onClear={() => { setSelectedPainTypes(new Set()); setDuration(null); }}
                onSubmit={() => setSubmitted(true)}
                submitLabel="Submit report"
            />
        </div>
    );
}