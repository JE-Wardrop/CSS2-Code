import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ACCENT, BG, BORDER, CARD, MUTED, TEXT } from "../theme";

// ─── MOCK DATA ────────────────────────────────────────────────────────────────
const MOCK_SUBMISSIONS = [
    { id: "s001", name: "Alex Johnson", age: 34, time: "Today, 9:14 AM", status: "Pending", regions: ["Lower Back", "Left Hip"], symptoms: ["Sharp Pain", "Stiffness", "Trouble Bending Over"], painTypes: ["Sharp", "Stiff"], duration: "1 week or more" },
    { id: "s002", name: "Maria Chen", age: 52, time: "Today, 8:02 AM", status: "Reviewed", regions: ["Chest", "Left Shoulder"], symptoms: ["Pressure Pain", "Heart Racing", "Tightness"], painTypes: ["Pressure", "Tight", "Heavy"], duration: "1 to 3 days" },
    { id: "s003", name: "Tom Nguyen", age: 28, time: "Yesterday, 4:45 PM", status: "Pending", regions: ["Head", "Neck"], symptoms: ["Headache", "Dizziness", "Nausea"], painTypes: ["Throbbing", "Pressure"], duration: "Started today" },
    { id: "s004", name: "Sara Okafor", age: 41, time: "Yesterday, 2:10 PM", status: "Urgent", regions: ["Right Knee", "Right Shin"], symptoms: ["Swelling", "Sharp Pain", "Bruise"], painTypes: ["Sharp", "Throbbing"], duration: "Started today" },
    { id: "s005", name: "James Patel", age: 67, time: "Yesterday, 11:30 AM", status: "Reviewed", regions: ["Left Thigh", "Left Calf"], symptoms: ["Cramping", "Weakness", "Muscle Pain"], painTypes: ["Cramping", "Dull", "Aching"], duration: "More than 3 days" },
    { id: "s006", name: "Emily Ross", age: 23, time: "2 days ago", status: "Pending", regions: ["Abdomen"], symptoms: ["Bloating", "Cramps", "Nausea"], painTypes: ["Cramping", "Dull"], duration: "Comes and goes" },
];

const STATUS_STYLE: Record<string, { bg: string; color: string; dot: string }> = {
    Pending: { bg: "#fef3c7", color: "#92400e", dot: "#d97706" },
    Reviewed: { bg: "#d1fae5", color: "#065f46", dot: "#059669" },
    Urgent: { bg: "#fee2e2", color: "#991b1b", dot: "#dc2626" },
};

// ─── SUB-COMPONENTS ───────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: string }) {
    const s = STATUS_STYLE[status];
    return (
        <span style={{ background: s.bg, color: s.color, borderRadius: 20, padding: "3px 10px", fontSize: 11, fontWeight: 700, display: "inline-flex", alignItems: "center", gap: 5, whiteSpace: "nowrap" }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: s.dot, display: "inline-block" }} />
            {status}
        </span>
    );
}

function Avatar({ name, size = 38 }: { name: string; size?: number }) {
    return (
        <div style={{ width: size, height: size, borderRadius: "50%", background: "#ede9fe", color: "#5b21b6", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 600, fontSize: 14, flexShrink: 0 }}>
            {name.charAt(0)}
        </div>
    );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
    return (
        <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: MUTED, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>{title}</div>
            {children}
        </div>
    );
}

function ChipRow({ items }: { items: string[] }) {
    return (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
            {items.map(it => (
                <span key={it} style={{ background: "#f5f3ff", color: ACCENT, borderRadius: 20, padding: "3px 10px", fontSize: 12, fontWeight: 500, border: "1px solid #e0d9f9" }}>
                    {it}
                </span>
            ))}
        </div>
    );
}

// ─── DETAIL PANEL ─────────────────────────────────────────────────────────────
function DetailPanel({ sub, onClose, onStatusChange }) {
    return (
        <motion.div
            initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 320, damping: 32 }}
            style={{ position: "absolute", top: 0, right: 0, bottom: 0, width: "min(400px, 100%)", background: CARD, borderLeft: `1px solid ${BORDER}`, display: "flex", flexDirection: "column", zIndex: 10, boxShadow: "-4px 0 24px rgba(0,0,0,.06)" }}
        >
            {/* Header */}
            <div style={{ padding: "14px 18px", borderBottom: `1px solid ${BORDER}`, display: "flex", alignItems: "center", gap: 12 }}>
                <button onClick={onClose}
                    style={{ background: "none", border: "none", color: MUTED, cursor: "pointer", padding: "2px 6px", borderRadius: 6, fontSize: 18, lineHeight: 1 }}
                    title="Close">
                    ←
                </button>
                <Avatar name={sub.name} />
                <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, fontSize: 15, color: TEXT, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{sub.name}</div>
                    <div style={{ fontSize: 12, color: MUTED, marginTop: 1 }}>Age {sub.age} · {sub.time}</div>
                </div>
                <StatusBadge status={sub.status} />
            </div>

            {/* Body */}
            <div style={{ flex: 1, overflowY: "auto", padding: "18px" }}>
                <Section title="Affected Areas"><ChipRow items={sub.regions} /></Section>
                <Section title="Symptoms"><ChipRow items={sub.symptoms} /></Section>
                <Section title="Pain Description"><ChipRow items={sub.painTypes} /></Section>
                <Section title="Duration">
                    <span style={{ fontSize: 14, color: TEXT, fontWeight: 500 }}>{sub.duration}</span>
                </Section>
                <Section title="Doctor Notes">
                    <textarea
                        placeholder="Add notes for this patient…"
                        rows={4}
                        style={{ width: "100%", borderRadius: 8, border: `1px solid ${BORDER}`, padding: "10px 12px", fontSize: 13, color: TEXT, background: BG, resize: "vertical", fontFamily: "inherit", boxSizing: "border-box" as const, lineHeight: 1.5 }}
                    />
                </Section>
            </div>

            {/* Actions */}
            <div style={{ padding: "12px 18px", borderTop: `1px solid ${BORDER}`, display: "flex", gap: 8 }}>
                <button onClick={() => onStatusChange(sub.id, "Reviewed")}
                    style={{ flex: 1, padding: "10px 0", borderRadius: 8, border: "none", background: "#d1fae5", color: "#065f46", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>
                    Mark Reviewed
                </button>
                <button onClick={() => onStatusChange(sub.id, "Urgent")}
                    style={{ flex: 1, padding: "10px 0", borderRadius: 8, border: "none", background: "#fee2e2", color: "#991b1b", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>
                    Flag as Urgent
                </button>
            </div>
        </motion.div>
    );
}

// ─── DOCTOR PAGE ──────────────────────────────────────────────────────────────
export default function DoctorPage() {
    const navigate = useNavigate();
    const [submissions, setSubmissions] = useState(MOCK_SUBMISSIONS);
    const [selected, setSelected] = useState<string | null>(null);
    const [filter, setFilter] = useState<"All" | "Pending" | "Urgent" | "Reviewed">("All");
    const [search, setSearch] = useState("");

    const changeStatus = (id: string, status: string) =>
        setSubmissions(prev => prev.map(s => s.id === id ? { ...s, status } : s));

    const activeSub = submissions.find(s => s.id === selected) ?? null;

    const visible = submissions.filter(s => {
        const mf = filter === "All" || s.status === filter;
        const ms = s.name.toLowerCase().includes(search.toLowerCase());
        return mf && ms;
    });

    const counts = {
        All: submissions.length,
        Pending: submissions.filter(s => s.status === "Pending").length,
        Urgent: submissions.filter(s => s.status === "Urgent").length,
        Reviewed: submissions.filter(s => s.status === "Reviewed").length,
    };

    return (
        <div style={{ width: "100%", height: "100vh", background: BG, fontFamily: "'Segoe UI', sans-serif", display: "flex", flexDirection: "column", overflow: "hidden", color: TEXT }}>

            {/* Header */}
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 20px", background: CARD, borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
                <button onClick={() => navigate("/")} style={{ background: "none", border: "none", color: MUTED, fontSize: 18, cursor: "pointer", lineHeight: 1, padding: "2px 6px" }}>←</button>
                <span style={{ color: "#d1d5db" }}>·</span>
                <span style={{ color: MUTED, fontSize: 13 }}>Doctor Portal</span>
                <div style={{ marginLeft: "auto", fontSize: 13, color: MUTED, display: "flex", alignItems: "center", gap: 8 }}>
                    <Avatar name="D" size={28} />
                    Dr. Smith
                </div>
            </div>

            {/* Filter tabs */}
            <div style={{ display: "flex", background: CARD, borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
                {(["All", "Pending", "Urgent", "Reviewed"] as const).map(f => (
                    <button key={f} onClick={() => setFilter(f)}
                        style={{ flex: 1, padding: "11px 0", border: "none", background: "none", borderBottom: filter === f ? `2px solid ${ACCENT}` : "2px solid transparent", color: filter === f ? ACCENT : MUTED, fontWeight: filter === f ? 600 : 400, fontSize: 13, cursor: "pointer", transition: "all .15s" }}>
                        {f}
                        <span style={{ marginLeft: 6, background: filter === f ? "#ede9fe" : "#f3f4f6", color: filter === f ? ACCENT : MUTED, borderRadius: 20, padding: "1px 7px", fontSize: 11, fontWeight: 600 }}>
                            {counts[f]}
                        </span>
                    </button>
                ))}
            </div>

            {/* Search */}
            <div style={{ padding: "10px 16px", background: CARD, borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
                <input
                    value={search} onChange={e => setSearch(e.target.value)}
                    placeholder="Search patients…"
                    style={{ width: "100%", boxSizing: "border-box" as const, padding: "8px 12px", borderRadius: 8, border: `1px solid ${BORDER}`, fontSize: 13, color: TEXT, background: BG, fontFamily: "inherit", outline: "none" }}
                />
            </div>

            {/* List + detail panel */}
            <div style={{ flex: 1, position: "relative", overflow: "hidden", display: "flex" }}>
                <div style={{ flex: 1, overflowY: "auto", padding: "12px 14px", display: "flex", flexDirection: "column", gap: 8 }}>
                    {visible.length === 0 && (
                        <div style={{ textAlign: "center", color: MUTED, marginTop: 60, fontSize: 14 }}>No submissions match your filter.</div>
                    )}
                    {visible.map(sub => (
                        <motion.div key={sub.id} layout whileHover={{ scale: 1.005 }} whileTap={{ scale: 0.995 }}
                            onClick={() => setSelected(sub.id === selected ? null : sub.id)}
                            style={{ background: CARD, borderRadius: 12, border: `1.5px solid ${selected === sub.id ? ACCENT : BORDER}`, padding: "14px 16px", cursor: "pointer", transition: "border-color .15s" }}>
                            <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
                                <Avatar name={sub.name} />
                                <div style={{ flex: 1, minWidth: 0 }}>
                                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
                                        <span style={{ fontWeight: 600, fontSize: 14, color: TEXT }}>{sub.name}</span>
                                        <span style={{ fontSize: 12, color: MUTED }}>Age {sub.age}</span>
                                        <span style={{ marginLeft: "auto" }}><StatusBadge status={sub.status} /></span>
                                    </div>
                                    <div style={{ fontSize: 12, color: MUTED, marginBottom: 7 }}>{sub.time}</div>
                                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                                        {sub.regions.map(r => (
                                            <span key={r} style={{ background: "#f5f3ff", color: ACCENT, borderRadius: 20, padding: "2px 10px", fontSize: 12, fontWeight: 500, border: "1px solid #e0d9f9" }}>{r}</span>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>

                <AnimatePresence>
                    {activeSub && (
                        <DetailPanel sub={activeSub} onClose={() => setSelected(null)} onStatusChange={changeStatus} />
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
}