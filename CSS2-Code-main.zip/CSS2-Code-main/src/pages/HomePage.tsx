import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ROLES } from "../constants";
import { ACCENT, BG, BORDER, CARD, MUTED, TEXT } from "../theme";
import EmergencyButton from "../components/EmergencyButton";

export default function HomePage() {
    const navigate = useNavigate();
    return (
        <div style={{ width: "100%", height: "100vh", background: BG, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: "'Segoe UI', sans-serif", padding: 24 }}>
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                <div style={{ textAlign: "center", marginBottom: 40 }}>
                    <h1 style={{ margin: "16px 0 6px", fontSize: 30, fontWeight: 800, color: TEXT }}>Who are you?</h1>
                    <p style={{ margin: 0, color: MUTED, fontSize: 15 }}>Select your role to continue</p>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 14, width: "min(380px, 92vw)" }}>
                    {ROLES.map((role, i) => (
                        <motion.button
                            key={role.id}
                            initial={{ opacity: 0, x: -24 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.1 + 0.2 }}
                            whileHover={{ scale: 1.03, boxShadow: "0 8px 28px rgba(124,58,237,0.18)" }}
                            whileTap={{ scale: 0.97 }}
                            onClick={() => navigate(`/${role.id}`)}
                            style={{
                                display: "flex", alignItems: "center", gap: 18,
                                background: CARD, border: `1.5px solid ${BORDER}`,
                                borderRadius: 16, padding: "20px 24px",
                                cursor: "pointer", textAlign: "left", width: "100%",
                            }}
                        >
                            <span style={{ fontSize: 36, lineHeight: 1 }}>{role.icon}</span>
                            <div>
                                <div style={{ fontSize: 16, fontWeight: 700, color: TEXT }}>{role.label}</div>
                                <div style={{ fontSize: 13, color: MUTED, marginTop: 2 }}>{role.desc}</div>
                            </div>
                            <span style={{ marginLeft: "auto", color: BORDER, fontSize: 20 }}>›</span>
                        </motion.button>
                    ))}
                </div>
            </motion.div>
            <EmergencyButton />

        </div>
    );
}