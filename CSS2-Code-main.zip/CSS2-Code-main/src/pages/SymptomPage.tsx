import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useNavigate, useLocation } from "react-router-dom";
import { ACCENT, BG, BORDER, CARD, MUTED, TEXT } from "../theme";
import { SYMPTOMS, REGION_SYMPTOM_MAP } from "../constants";
import StepIndicator from "../components/StepIndicator";
import SubmittedView from "../components/SubmittedView";
import StickyBottomBar from "../components/StickyBottomBar";

function SymptomCard({ symptom, active, onToggle }) {
    return (
        <motion.div
            layout
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => onToggle(symptom.id)}
            style={{
                borderRadius: 16, overflow: "hidden",
                border: `2px solid ${active ? "#7c3aed" : BORDER}`,
                background: active ? "#faf8ff" : CARD,
                cursor: "pointer",
                transition: "border-color 0.15s, background 0.15s",
                position: "relative",
                display: "flex", flexDirection: "column",
            }}
        >
            <AnimatePresence>
                {active && (
                    <motion.div
                        initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }}
                        style={{
                            position: "absolute", top: 8, right: 8, zIndex: 2,
                            background: "#7c3aed", borderRadius: "50%",
                            width: 26, height: 26,
                            display: "flex", alignItems: "center", justifyContent: "center",
                            fontSize: 13, color: "#fff", fontWeight: 800,
                            boxShadow: "0 2px 8px rgba(124,58,237,0.4)",
                        }}
                    >✓</motion.div>
                )}
            </AnimatePresence>
            <div style={{ width: "100%", aspectRatio: "4 / 3", overflow: "hidden", background: "#f5f3ff", flexShrink: 0 }}>
                <img
                    src={new URL(`../assets/images/${symptom.file}`, import.meta.url).href}
                    alt={symptom.label}
                    draggable={false}
                    style={{
                        width: "100%", height: "100%", objectFit: "cover",
                        filter: active ? "brightness(0.93) saturate(1.1)" : "none",
                        transition: "filter 0.15s",
                        userSelect: "none", display: "block",
                    }}
                />
            </div>
            <div style={{
                flex: 1, padding: "10px 10px 12px", textAlign: "center",
                fontSize: 15, fontWeight: active ? 700 : 500,
                color: active ? ACCENT : TEXT, lineHeight: 1.3,
                display: "flex", alignItems: "center", justifyContent: "center",
            }}>
                {symptom.label}
            </div>
        </motion.div>
    );
}

function OtherCard({ active, onToggle }) {
    return (
        <motion.div
            layout
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => onToggle("other")}
            style={{
                borderRadius: 16, overflow: "hidden",
                border: `2px solid ${active ? "#7c3aed" : BORDER}`,
                background: active ? "#faf8ff" : CARD,
                cursor: "pointer",
                transition: "border-color 0.15s, background 0.15s",
                position: "relative",
                display: "flex", flexDirection: "column",
            }}
        >
            <AnimatePresence>
                {active && (
                    <motion.div
                        initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }}
                        style={{
                            position: "absolute", top: 8, right: 8, zIndex: 2,
                            background: "#7c3aed", borderRadius: "50%",
                            width: 26, height: 26,
                            display: "flex", alignItems: "center", justifyContent: "center",
                            fontSize: 13, color: "#fff", fontWeight: 800,
                            boxShadow: "0 2px 8px rgba(124,58,237,0.4)",
                        }}
                    >✓</motion.div>
                )}
            </AnimatePresence>
            <div style={{
                width: "100%", aspectRatio: "4 / 3",
                background: active ? "#ede9fe" : "#f0edf9",
                display: "flex", alignItems: "center", justifyContent: "center",
                transition: "background 0.15s", flexShrink: 0,
            }}>
                <span style={{ fontSize: 40, color: active ? "#7c3aed" : "#c4b5fd", fontWeight: 300, lineHeight: 1 }}>+</span>
            </div>
            <div style={{
                flex: 1, padding: "10px 10px 12px", textAlign: "center",
                fontSize: 15, fontWeight: active ? 700 : 500,
                color: active ? ACCENT : TEXT, lineHeight: 1.3,
                display: "flex", alignItems: "center", justifyContent: "center",
            }}>
                Other
            </div>
        </motion.div>
    );
}

export default function SymptomPage() {
    const navigate = useNavigate();
    const location = useLocation();
    const passedRegions = location.state?.selectedRegions ?? [];

    const [selected, setSelected] = useState(new Set<string>());
    const [submitted, setSubmitted] = useState(false);
    const [note, setNote] = useState("");
    const [anonymous, setAnonymous] = useState(false);

    const toggle = (id: string) => setSelected(prev => {
        const next = new Set(prev);
        next.has(id) ? next.delete(id) : next.add(id);
        return next;
    });

    const relevantSymptomIds = passedRegions.length === 0
        ? null
        : new Set(passedRegions.flatMap(r => REGION_SYMPTOM_MAP[r.id] ?? []));

    const visibleSymptoms = (relevantSymptomIds
        ? SYMPTOMS.filter(s => relevantSymptomIds.has(s.id))
        : SYMPTOMS
    ).filter(s => s.id !== "other");

    const selectedSymptoms = [
        ...SYMPTOMS.filter(s => selected.has(s.id)),
        ...(selected.has("other") ? [{ id: "other", label: "Other" }] : []),
    ];

    if (submitted) {
        return (
            <SubmittedView
                selectedRegions={passedRegions}
                selectedSymptoms={selectedSymptoms}
                onReset={() => { setSelected(new Set()); setSubmitted(false); navigate("/patient"); }}
                onBack={() => navigate("/")}
            />
        );
    }

    return (
        <div style={{ width: "100%", height: "100vh", background: BG, fontFamily: "'Segoe UI', sans-serif", display: "flex", flexDirection: "column", overflow: "hidden", color: TEXT }}>

            {/* Header */}
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 20px", background: CARD, borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
                <button onClick={() => navigate(-1)} style={{ background: "none", border: "none", color: MUTED, fontSize: 24, cursor: "pointer", lineHeight: 1, padding: "0 4px" }}>‹</button>
                <span style={{ color: MUTED, fontSize: 13, marginLeft: 2 }}>Patient Portal</span>
                <div style={{ marginLeft: "auto" }}><StepIndicator currentStep={2} /></div>
            </div>

            {/* Title */}
            <div style={{ padding: "18px 20px 12px", flexShrink: 0 }}>
                <h1 style={{ margin: "0 0 3px", fontSize: 22, fontWeight: 800, color: TEXT }}>What are your symptoms?</h1>
                <p style={{ margin: 0, color: MUTED, fontSize: 14 }}>
                    Tap all that apply.
                    {relevantSymptomIds && (
                        <span style={{ marginLeft: 6, color: ACCENT, fontWeight: 600 }}>
                            Showing {visibleSymptoms.length} for your selected {passedRegions.length > 1 ? "areas" : "area"}.
                        </span>
                    )}
                </p>

                {passedRegions.length > 0 && (
                    <div style={{ marginTop: 10, display: "flex", flexWrap: "wrap", gap: 6, alignItems: "center" }}>
                        <span style={{ fontSize: 12, color: MUTED }}>Areas:</span>
                        {passedRegions.map(r => (
                            <span key={r.id} style={{ background: "#f5f3ff", color: ACCENT, borderRadius: 20, padding: "4px 12px", fontSize: 13, fontWeight: 700, border: "1.5px solid #c4b5fd" }}>
                                {r.label}
                            </span>
                        ))}
                    </div>
                )}



            </div>

            {/* Scrollable symptom grid */}
            <div style={{ flex: 1, overflowY: "auto", padding: "0 14px 16px" }}>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 12 }}>
                    {visibleSymptoms.map(s => (
                        <SymptomCard key={s.id} symptom={s} active={selected.has(s.id)} onToggle={toggle} />
                    ))}
                    <OtherCard active={selected.has("other")} onToggle={toggle} />
                </div>

                {/* Free-text note */}
                <div style={{ marginTop: 18 }}>
                    <label style={{ fontSize: 13, fontWeight: 700, color: MUTED, display: "block", marginBottom: 6 }}>
                        Anything else you want to tell us? (optional)
                    </label>
                    <textarea
                        value={note}
                        onChange={e => setNote(e.target.value)}
                        placeholder="Describe your symptoms in your own words…"
                        rows={3}
                        style={{
                            width: "100%", boxSizing: "border-box",
                            borderRadius: 12, border: `1.5px solid ${BORDER}`,
                            padding: "10px 14px", fontSize: 14, color: TEXT, background: CARD,
                            resize: "vertical", fontFamily: "'Segoe UI', sans-serif",
                        }}
                    />
                </div>

                <div style={{ height: 80 }} />
            </div>

            <StickyBottomBar
                canSubmit={selected.size > 0}
                showClear={selected.size > 0}
                onClear={() => setSelected(new Set())}
                onSubmit={() => navigate("/pain", { state: { selectedRegions: passedRegions, selectedSymptoms, note, anonymous } })}
                submitLabel="Next →"
            />
        </div>
    );
}