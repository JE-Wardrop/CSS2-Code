import { AnimatePresence, motion } from "framer-motion";
import { HashRouter, Route, Routes, useLocation } from "react-router-dom";
import HomePage from "./pages/HomePage";
import PatientPage from "./pages/PatientPage";
import SymptomPage from "./pages/SymptomPage";
import PainDescriptionPage from "./pages/PainDescriptionPage";
import DoctorPage from "./pages/DoctorPage";
import EmergencyButton from "./components/EmergencyButton";

const fadeSlide = {
  initial: { opacity: 0, x: 40 },
  animate: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -40 },
  transition: { duration: 0.25 },
};

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}>
            <HomePage />
          </motion.div>
        } />
        <Route path="/patient" element={<motion.div {...fadeSlide}><PatientPage /></motion.div>} />
        <Route path="/symptoms" element={<motion.div {...fadeSlide}><SymptomPage /></motion.div>} />
        <Route path="/pain" element={<motion.div {...fadeSlide}><PainDescriptionPage /></motion.div>} />
        <Route path="/doctor" element={<motion.div {...fadeSlide}><DoctorPage /></motion.div>} />
      </Routes>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <HashRouter>
      <AnimatedRoutes />
    </HashRouter>
  );
}